﻿
namespace ServicoDeOrdenacaoDDD.ServiceBooksOrderer.Domain.IServiceOrderTest
{
    public interface IServiceOrderShowTest
    {
        void ShowMeOrderByTests(dynamic result, int order);
    }
}
