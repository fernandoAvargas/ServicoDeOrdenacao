﻿
namespace ServicoDeOrdenacaoDDD.ServiceBooksOrder.Domain.ListOrderer
{ 
    public enum ListOrderes
    {
         Nop = 0,
         Asc = 1,
         Desc = 2
    }
}
