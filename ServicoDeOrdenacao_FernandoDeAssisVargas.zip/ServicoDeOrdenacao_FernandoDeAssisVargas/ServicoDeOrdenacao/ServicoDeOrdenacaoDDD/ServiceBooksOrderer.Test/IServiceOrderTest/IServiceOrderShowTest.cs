﻿
namespace ServicoDeOrdenacaoDDD.ServiceBooksOrderer.Test.IServiceOrderTest
{
    public interface IServiceOrderShowTest
    {
        void ShowMeOrderByTests(dynamic result, int order);
    }
}
