﻿
namespace ServicoDeOrdenacaoDDD.ServiceBooksOrder.Infra.ListOrderer
{
 
    public enum ListOrderes
    {
         Nop = 0,
         Asc = 1,
         Desc = 2
    }
}
